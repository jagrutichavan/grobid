package org.grobid.core.data;

import org.grobid.core.mock.MockContext;
import org.grobid.core.utilities.GrobidProperties;
import org.junit.*;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class BiblioItemTest {

    private static BiblioItem biblioItem;

    @BeforeClass
    public  static void testSetUp() throws Exception {
        MockContext.setInitialContext();
        GrobidProperties.getInstance();
        biblioItem = new BiblioItem();
    }

    @Test
    public void Test_toTEIAuthorBlock_should_have_suffix_tag() {

        // ... Arrange
        int nTb = 6;
        Person person = new Person();
        person.setFirstName("Gajendra");
        person.setLastName("Pratap");
        person.setSuffix("Jr");
        String expectedResult = "<suffix>" + person.getSuffix() +"</suffix>";
        List<Person> fullAuthors = new ArrayList<>();
        fullAuthors.add(person);
        biblioItem.setFullAuthors(fullAuthors);

        // ... Act
        String actualAuthorBlock = biblioItem.toTEIAuthorBlock(nTb);

        // ... Assert
        assertTrue(actualAuthorBlock.contains(expectedResult));
    }

    @Test
    public void Test_toTEIAuthorBlock_should_have_particle_tag() {

        // ... Arrange
        int nTb = 6;
        Person person = new Person();
        person.setFirstName("Gajendra");
        person.setLastName("Pratap");
        person.setSuffix("Jr");
        person.setParticle("Van");
        String expectedResult = "<particle>" + person.getParticle() +"</particle>";
        List<Person> fullAuthors = new ArrayList<>();
        fullAuthors.add(person);
        biblioItem.setFullAuthors(fullAuthors);

        // ... Act
        String actualAuthorBlock = biblioItem.toTEIAuthorBlock(nTb);

        // ... Assert
        assertTrue(actualAuthorBlock.contains(expectedResult));
    }

    @Test
    public void Test_toTEIAuthorBlock_should_have_authorbiography_tag() {

        // ... Arrange
        int nTb = 6;
        Person person = new Person();
        person.setFirstName("Gajendra");
        person.setLastName("Pratap");
        person.setSuffix("Jr");
        person.setParticle("Van");
        person.setBiography("biographytext");
        String expectedResult = "<authorbiography>" + person.getBiography() +"</authorbiography>";
        List<Person> fullAuthors = new ArrayList<>();
        fullAuthors.add(person);
        biblioItem.setFullAuthors(fullAuthors);

        // ... Act
        String actualAuthorBlock = biblioItem.toTEIAuthorBlock(nTb);

        // ... Assert
        assertTrue(actualAuthorBlock.contains(expectedResult));
    }
}
