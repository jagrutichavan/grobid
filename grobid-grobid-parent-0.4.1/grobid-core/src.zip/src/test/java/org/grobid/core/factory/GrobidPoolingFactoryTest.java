package org.grobid.core.factory;

import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.commons.pool.impl.StackObjectPool;
import org.grobid.core.engines.Engine;
import org.junit.Test;

public class GrobidPoolingFactoryTest {

	@Test
	public void testnewPoolInstance() throws Exception {
		// GrobidPoolingFactory factory = GrobidPoolingFactory.newInstance();
		// StackObjectPool pool = new StackObjectPool(factory);
		// GenericObjectPool genericPool = GrobidPoolingFactory.newPoolInstance();
		// Engine engine = (Engine)genericPool.borrowObject();
		// engine.processDate("10 November 2012");
		// engine.close();
	}

}
