package org.grobid.core.data;

import java.util.ArrayList;
import java.util.List;

import org.grobid.core.utilities.TextUtilities;

/**
 * Class for representing and exchanging person information, e.g. author or editor.
 *
 * @author Patrice Lopez
 */
public class Person {
    private String firstName = null;
    private String middleName = null;
    private String lastName = null;
    private String title = null;
    private String suffix = null;
    private String rawName = null; // raw full name if relevant, e.g. name exactly as displayed
    private String particle = null;
    private String authorDegree = null;
    private boolean corresp = false;

    private List<String> affiliationBlocks = null;
    private List<Affiliation> affiliations = null;
    private List<String> affiliationMarkers = null;
    private List<String> markers = null;

    private String email = null;

    private String biography = null;

    private List<String> phones =null;

    private List<String> urls = null;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String f) {
//        firstName = normalizeName(f);
        firstName = f;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String f) {
//        middleName = normalizeName(f);
        middleName = f;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String f) {
//        lastName = normalizeName(f);
        lastName = f;
    }

    public String getRawName() {
         return rawName;
    }

    public void setRawName(String name) {
         rawName = name;
    }

    public String getParticle() {
        return particle;
    }

    public void setParticle(String f) {
//        particle = normalizeName(f);
        particle = f;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String f) {
//        title = normalizeName(f);
        title = f;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String s) {
//        suffix = normalizeName(s);
        suffix = s;
    }

    public boolean getCorresp() {
        return corresp;
    }

    public void setCorresp(boolean b) {
        corresp = b;
    }

    public String getAuthorDegree() {
        return authorDegree;
    }

    public void setAuthorDegree(String f) {
//        authorDegree = normalizeName(f);
        authorDegree = f;
    }

    public List<String> getAffiliationBlocks() {
        return affiliationBlocks;
    }

    public void addAffiliationBlocks(String f) {
        if (affiliationBlocks == null)
            affiliationBlocks = new ArrayList<String>();
        affiliationBlocks.add(f);
    }

    public List<org.grobid.core.data.Affiliation> getAffiliations() {
        return affiliations;
    }

    public void addAffiliation(org.grobid.core.data.Affiliation f) {
        if (affiliations == null)
            affiliations = new ArrayList<org.grobid.core.data.Affiliation>();
        affiliations.add(f);
    }

    public List<String> getAffiliationMarkers() {
        return affiliationMarkers;
    }

    public void addAffiliationMarker(String s) {
        if (affiliationMarkers == null)
            affiliationMarkers = new ArrayList<String>();
        affiliationMarkers.add(s);
    }

    public void setAffiliations(List<org.grobid.core.data.Affiliation> f) {
        affiliations = f;
    }

    public List<String> getMarkers() {
        return markers;
    }

    public void addMarker(String f) {
        if (markers == null)
            markers = new ArrayList<String>();
		f = f.replace(" ", "");
        markers.add(f);
    }

    public String getEmail() {
        return email;
    }

    public List<String> getPhones() {return phones;}

    public void setEmail(String f) {
        email = f;
    }

    public String getBiography() {
        return biography;
    }

    public void setBiography(String s) {
//        biography = normalizeName(s);
        biography = s;
    }

    public void addPhone(String ph) {
        if (phones == null){
            phones = new ArrayList<String>();
        }
        if (!phones.contains(ph)){
            phones.add(ph);
        }
    }

    public List<String> getUrls() {return urls;}

    public void addUrl(String url) {
        if (urls == null){
            urls = new ArrayList<String>();
        }
        if (!urls.contains(url)){
            urls.add(url);
        }
    }

    public boolean notNull() {
        if ((firstName == null) &&
                (middleName == null) &&
                (lastName == null) &&
                (title == null)
                )
            return false;
        else
            return true;
    }

    public String toString() {
        String res = "";
        if (title != null)
            res += title + " ";
        if (firstName != null)
            res += firstName + " ";
        if (middleName != null)
            res += middleName + " ";
        if (lastName != null)
            res += lastName + " ";
        if (suffix != null)
            res += suffix;
        if (particle != null)
            res += particle + " ";
        if (email != null) {
            res += " (email:" + email + ")";
        }
        if (phones != null) {
            res += " (phones:" + phones + ")";
        }
        if (authorDegree != null) {
            res += authorDegree + " ";
        }
        if (biography != null) {
            res += biography + " ";
        }
        return res.trim();
    }

    public String toTEI() {
        if ( (firstName == null) && (middleName == null) &&
                (lastName == null) ) {
            return null;
        }
        String res = "<persName>";
        if (title != null)
            res += "<roleName>" + title + "</roleName>";
        if (firstName != null)
            res += "<forename type=\"first\">" + firstName + "</forename>";
        if (middleName != null)
            res += "<forename type=\"middle\">" + middleName + "</forename>";
        if (lastName != null)
            res += "<surname>" + lastName + "</surname>";
        if (suffix != null)
            res += "<genName>" + suffix + "</genName>";
        if (particle != null)
            res += "<particle>" + particle + "</particle>";
        if (authorDegree != null)
            res += "<authordegree>" + authorDegree + "</authordegree>";
        res += "</persName>";

        return res;
    }

    // list of character delimiters for capitalising names
 	private static final String NAME_DELIMITERS = "-.,;:/_ ";

//    static public String normalizeName(String inputName) {
//		return TextUtilities.capitalizeFully(inputName, NAME_DELIMITERS);
//    }
	
	/**
	 *  Return true if the person structure is a valid person name, in our case
	 *  with at least a lastname or a raw name.
	 */
	public boolean isValid() {
		if ( (lastName == null) && (rawName == null) )
			return false;
		else 
			return true;
	}

    /**
     *
     * person is identified as corresponding author
     * if it has asterisk marker with
     */
	public boolean isCorresponding() {
	    if (markers != null) {
            for (String m : markers) {
                if (m.contains("*")) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean equals(Object o) {
	    Person p = (Person)o;
	    return (this.getFirstName() == p.getFirstName() && this.getLastName() == p.getLastName() && this.getMiddleName() == p.getMiddleName());
    }

    @Override
    public int hashCode() {
	    int hash = 5;
	    hash = 89*hash + (this.getFirstName() != null ? this.getFirstName().hashCode() : 0);
	    hash = 89*hash + (this.getMiddleName() != null ? this.getMiddleName().hashCode() : 0);
	    hash = 89*hash + (this.getLastName() != null ? this.getLastName().hashCode() : 0);
        return hash;
    }   
}
