package org.grobid.core.engines.counters;

/**
 * User: zholudev
 * Date: 2/25/14
 */
public enum CitationParserCounters {
    SEGMENTED_REFERENCES,
    NULL_SEGMENTED_REFERENCES_LIST,
    EMPTY_REFERENCES_BLOCKS, NOT_EMPTY_REFERENCES_BLOCKS
}
