package org.grobid.core.lang;

/**
 * User: zholudev
 * Date: 11/24/11
 * Time: 11:03 AM
 */
public interface LanguageDetectorFactory {
    public LanguageDetector getInstance();
}
