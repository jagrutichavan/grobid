package org.grobid.core.data.util;

import org.grobid.core.data.Person;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by aman on 4/5/17.
 */
public class AuthorUrlAssigner {

    private static String flag = "0";
    public static void assign(List<Person> fullAuthors, String urlEmail){
        String email = urlEmail.split("\t")[1].toLowerCase();
        String url = urlEmail.split("\t")[0];
        if (fullAuthors != null){
            String autEmail = null;
            if(fullAuthors.size() == 1){
                fullAuthors.get(0).addUrl(url);
            }
            else{
                //look for the email appearing after and before the url
                //the url is most likely to be in association with that
                int i = 0;
                for (Person aut:fullAuthors){
                    autEmail = aut.getEmail();
                    if (autEmail != null) {
                        autEmail = autEmail.toLowerCase();
                        if (autEmail.contains(email)) {
                            fullAuthors.get(i).addUrl(url);
                            break;
                        }
                    }
                    i++;
                }

            }
        }

    }
    private static String getEmailName(Stack<String> emLines){
        String tok = null;
        StringBuilder emailStr = new StringBuilder();
        String line = null;
        line = emLines.pop();
        emailStr.append(line.split("\t")[0]);
        String preTok ="";

        while (emLines.size()>0){
            line = emLines.pop();
            tok = line.split("\t")[0];
            if (tok =="." | tok =="_" |tok =="-"){
                emailStr.append(tok);
            }
            else if (preTok =="." | preTok =="_" |preTok =="-"){
                emailStr.append(tok);
            }
            else{
                break;
            }
            preTok = tok;
        }
        return emailStr.toString();
    }

    private static String getCorrespondingEmail(Stack<String> follLines,Stack<String> prevLines){
        String line = null;
        String token = null;
        String prevEmail = null;
        String follEmail = null;
        if (prevLines !=null){
            while (prevLines.size()>0){
                line = prevLines.pop();
                token = line.split("\t")[0];
                if (token.contains("@")){
                    prevLines.push(line);
                    prevEmail = getEmailName(prevLines);
                }
            }
        }
        if (follLines != null){
            while (follLines.size()>0){
                line = follLines.pop();
                token = line.split("\t")[0];
                if (token.contains("@")){
                    follLines.push(line);
                    follEmail = getEmailName(follLines);
                }
            }
        }
        if (prevEmail!=null && follEmail==null){
            return prevEmail;
        }
        else if (prevEmail==null && follEmail!=null){
            return follEmail;
        }
        else if (prevEmail!=null && follEmail!=null){
            if (flag.equals("1")){
                return prevEmail;
            }
            else if (flag.equals("2")){
                return follEmail;
            }
        }
        return "notFound";
    }
    public static String mapUrlEmail(String result,String url) {
        flag = "0";
        String correspondingEmail = null;
        String urlString = null;
        Stack<String> follLines = new Stack<String>();
        SizedStack<String> prevLines = new SizedStack<>(20);
        StringTokenizer st = new StringTokenizer(result, "\n");
        String tok = null;
        String line = null;
        StringBuilder sb = null;
        while (st.hasMoreTokens()) {
            line = st.nextToken();
            if (flag.equals("0")){
                if (line.endsWith("I-<email>")){
                    //email has appeared before url
                    flag = "1";
                    continue;
                }
            }
            if (line.endsWith("I-<web>")) {
                if (flag.equals("0")){
                    //url has appeared before email
                    flag = "2";
                }
                if (sb != null) {
                    String strUrl = sb.toString();
                    if (isExactMatch(strUrl,url)) {
                        int i = 0;
                        while (st.hasMoreTokens() && i < 20) {
                            line = st.nextToken();
                            follLines.push(line);
                            i++;
                        }
                        correspondingEmail = getCorrespondingEmail(follLines, prevLines);
                        break;
                    }
                }
                sb = new StringBuilder();
                tok = line.split("\t")[0];
                sb.append(tok);
            } else if (line.endsWith("<web>")) {
                tok = line.split("\t")[0];
                //if url doesnt have starting label as I-web instead just web
                if (sb == null){
                    sb = new StringBuilder();
                }
                sb.append(tok);
                if (!st.hasMoreTokens()){
                    String strUrl = sb.toString();
                    if (isExactMatch(strUrl,url)) {
                        int i = 0;
                        while (st.hasMoreTokens() && i < 20) {
                            line = st.nextToken();
                            follLines.push(line);
                            i++;
                        }
                        correspondingEmail = getCorrespondingEmail(follLines, prevLines);
                        break;
                    }
                }

            } else {
                if (sb != null) {
                    String strUrl = sb.toString();
                    if (isExactMatch(strUrl,url)) {
                        int i = 0;
                        while (st.hasMoreTokens() && i < 20) {
                            line = st.nextToken();
                            follLines.push(line);
                            i++;
                        }
                        correspondingEmail = getCorrespondingEmail(follLines, prevLines);
                        break;
                    }
                    sb = null;
                }
                //keep preceding line history for email lookup
                prevLines.push(line);
            }
        }
        return correspondingEmail;
    }

    public static boolean isExactMatch(String urlStr,String url){
        Pattern p = Pattern.compile("https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b"+
                "[-a-zA-Z0-9@:%_\\+.~#?&//=]*",Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(urlStr);
        String wb = null;
        while(m.find()) {
            if (m.group(0) != null) {
                wb = m.group(0).trim();
                if (wb.equals(url)) {
                    return true;
                }
            }
        }
        return false;
    }
}
