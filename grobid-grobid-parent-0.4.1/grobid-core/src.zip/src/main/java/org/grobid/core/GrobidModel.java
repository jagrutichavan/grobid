package org.grobid.core;

/**
 * Created by lfoppiano on 19/08/16.
 */
public interface GrobidModel {
    String getFolderName();
    String getModelPath();
    String getModelName();
    String getTemplateName();
    String toString();

}
