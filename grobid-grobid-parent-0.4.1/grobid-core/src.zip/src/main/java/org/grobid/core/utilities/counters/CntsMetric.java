package org.grobid.core.utilities.counters;

/**
 * Date: 6/29/12
 * Time: 4:47 PM
 *
 * @author Vyacheslav Zholudev
 */
public interface CntsMetric {
    String getMetricString(CntManager cntManager);
}
